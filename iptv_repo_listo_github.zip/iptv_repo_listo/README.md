# IPTV listo para GitHub

Este paquete ya está preparado para subirlo a GitHub y usarlo como URL en apps IPTV.

## Qué trae
- `playlists/main.m3u` → lista principal
- listas separadas por país y por temática
- carpeta `epg/` con instrucciones

## Pasos rápidos
1. Crea un repositorio público en GitHub, por ejemplo `iptv`.
2. Sube **todo** el contenido de esta carpeta.
3. Abre el archivo `playlists/main.m3u` en GitHub.
4. Pulsa **Edit** y reemplaza `TUUSUARIO` por tu usuario real de GitHub.
5. Guarda los cambios.

## URL final para la app
Cuando esté subido, tu URL será:

`https://raw.githubusercontent.com/TUUSUARIO/iptv/main/playlists/main.m3u`

Cambia `TUUSUARIO` por tu usuario real.

## EPG
En la app IPTV añade esta EPG:

`https://www.tdtchannels.com/epg/TV.xml.gz`

## Recomendación
Para no perderte:
- usa `main.m3u` si quieres todo junto
- usa las listas dentro de `playlists/` si quieres cargar solo países concretos

## Listas incluidas
- `playlists/abierto.m3u`
- `playlists/argentina.m3u`
- `playlists/chile.m3u`
- `playlists/cine.m3u`
- `playlists/cultura.m3u`
- `playlists/deportes.m3u`
- `playlists/entretenimiento.m3u`
- `playlists/espana.m3u`
- `playlists/general.m3u`
- `playlists/infantil.m3u`
- `playlists/internacional.m3u`
- `playlists/mexico.m3u`
- `playlists/musica.m3u`
- `playlists/noticias.m3u`
- `playlists/portugal.m3u`
