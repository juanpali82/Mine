# reemplaza TUUSUARIO por tu usuario y luego ejecuta:
# python update_main.py TUUSUARIO
import sys
from pathlib import Path
user = sys.argv[1]
p = Path("playlists/main.m3u")
text = p.read_text(encoding="utf-8")
p.write_text(text.replace("TUUSUARIO", user), encoding="utf-8")
print("Actualizado:", p)
